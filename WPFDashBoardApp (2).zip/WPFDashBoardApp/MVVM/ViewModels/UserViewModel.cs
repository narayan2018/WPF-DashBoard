﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using WPFDashBoardApp.Data;
using WPFDashBoardApp.MVVM.Models;
using WPFDashBoardApp.MVVM.Views;

namespace WPFDashBoardApp.MVVM.ViewModels
{
    internal class UserViewModel : INotifyPropertyChanged
    {

        public ICommand UserLoginCommand { get; set; }
        public ICommand UserResetCommand { get; set; }
        public UserViewModel() 
        {
            UserLoginCommand = new RelayCommand(UserLogin, CanUserLogin);
            UserResetCommand = new RelayCommand(ResetPage);
        }

        private void ResetPage(object obj)
        {
            UserName = "";
            Password = "";
        }

        private bool CanUserLogin(object arg)
        {
            return true;
        }

        private string _userName;
        public string UserName
        {
            get { return _userName; }
            set
            {
                _userName = value;
                OnPropertyChanged("UserName");
            }
        }

        private string _password;
        public string Password
        {
            get { return _password; }
            set
            {
                _password = value;
                OnPropertyChanged("Password");
            }
        }

        private string _mesage;
        public string Message
        {
            get { return _mesage; }
            set
            {
                _mesage = value;
                OnPropertyChanged("Message");
            }
        }

        private void UserLogin(object value)
        {
            User user = new User();
            user.UserName = _userName;
            user.UserPassword=_password;

            Message = String.Empty;
            UserService userService = new UserService();

            bool IsLoginSuccess = (string.IsNullOrEmpty(user.UserName) || string.IsNullOrEmpty(user.UserPassword))? false: userService.ValidateLogin(user);

            if (IsLoginSuccess)
            {
               
                DashBoard winDashBoard= new DashBoard(user);

                winDashBoard.Show();

                ((Window)value).Close();
            }
            else
            {
                Message = "Invalid user name or Password";
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }
    }
}
