﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using WPFDashBoardApp.Data;
using WPFDashBoardApp.MVVM.Models;
using WPFDashBoardApp.MVVM.Views;

namespace WPFDashBoardApp.MVVM.ViewModels
{
    internal class DashBoardViewModel: INotifyPropertyChanged
    {
        public ICommand LogOutCommand { get; set; }
        public ICommand AddCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public ICommand DeleteCommand { get; set; }

        public DashBoardViewModel(User user)
        {
            LogOutCommand = new RelayCommand(LogOutPage);
            AddCommand = new RelayCommand(AddPersonData);
            UpdateCommand = new RelayCommand(UpdatePersonData);
            DeleteCommand = new RelayCommand(DeletePersonData);
            Persons = new ObservableCollection<Person>();

            LoggedInUser="User : " + user.UserName;
            GetPersonaData();
        }

        private void DeletePersonData(object obj)
        {
            Person p = (obj != null) ? (Person)obj : null;

            if (p != null && p.Id > 0)
            {
                var person = new PersonService();
                bool IsSucess = person.DeletePerson(p);

                if (IsSucess)
                {
                    MessageBox.Show("Person " + p.Name + " has been deleted successfully.");
                }
                else
                {
                    MessageBox.Show("It failed to delete " + p.Name + ".");
                }
                GetPersonaData();
            }
            else
            {
                MessageBox.Show("Please select person");
            }
        }

        private ObservableCollection<Person> _persons;
        public ObservableCollection<Person> Persons
        {
            get { return _persons; }
            set
            {
                _persons = value;
                OnPropertyChanged("Persons");
            }
        }

        private string _loggedInUser;
        public string LoggedInUser
        {
            get { return _loggedInUser; }
            set
            {
                _loggedInUser = value;
                OnPropertyChanged("LoggedInUser");
            }
        }

        private Person _selectedPerson;
        public Person SelectedPerson
        {
            get { return _selectedPerson; }
            set
            {
                _selectedPerson = value;
                OnPropertyChanged("SelectedPerson");
            }
        }


        private void AddPersonData(object obj)
        {
            Person p=new Person();
            Window win = new PersonPage(p);

            win.ShowDialog();

            GetPersonaData();
        }


        private void UpdatePersonData(object obj)
        {

            if(obj!=null)
            {
                Person p = (Person)obj;
                Window win = new PersonPage(p);

                win.ShowDialog();

                GetPersonaData();
            }
            else
            {
                MessageBox.Show("Please select person");
            }
            
        }

        private void LogOutPage(object obj)
        {
            bool IsLoginSuccess = true;
            if (IsLoginSuccess)
            {
                var winDashBoard = new MainWindow();

                winDashBoard.Show();

                ((Window)obj).Close();
            }   
        }

        private void GetPersonaData()
        {
            PersonService pService = new PersonService();
            Persons = pService.GetAllPerson();

            
            
            OnPropertyChanged("Persons");
        }


        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }
    }
}
