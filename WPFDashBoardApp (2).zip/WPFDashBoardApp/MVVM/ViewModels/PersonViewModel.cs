﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Windows.Input;
using WPFDashBoardApp.Data;
using WPFDashBoardApp.MVVM.Models;

namespace WPFDashBoardApp.MVVM.ViewModels
{
    internal class PersonViewModel : INotifyPropertyChanged
    {
        public ICommand SaveCommand { get; set; }
        public ICommand ClearCommand { get; set; }
        public ICommand BrowseCommand { get; set; }
        private bool IsUpdate = false;
        
        public PersonViewModel(Person p)
        {
            Persons = new Person();
            SaveCommand = new RelayCommand(SavePersonData);
            ClearCommand = new RelayCommand(ClearPersonData);

            BrowseCommand = new RelayCommand(BrowseFile);

            SetPersonData(Persons,p);
        }

        private void SetPersonData(Person persons, Person p)
        {
            if (p != null && !string.IsNullOrEmpty(p.Name))
            {
                persons.Id = p.Id;
                persons.Name = p.Name;
                persons.Mobile = p.Mobile;
                persons.Gender = p.Gender;
                persons.Address = p.Address;
                persons.Email = p.Email;

                IsUpdate = true;
                SaveOrUpdateText = " Update ";
            }
            else
            {
                SaveOrUpdateText = " Add ";
            }
            OnPropertyChanged("Persons");
            OnPropertyChanged("SaveOrUpdateText");
        }

        private Person _persons;
        public Person Persons
        {
            get { return _persons; }
            set
            {
                _persons = value;
                OnPropertyChanged("Persons");
            }
        }

        private string _message;
        public string Message
        {
            get { return _message; }
            set
            {
                _message = value;
                OnPropertyChanged("Message");
            }
        }

        private bool _isMaleChecked;
        public bool IsMaleChecked
        {
            get { return _isMaleChecked; }
            set
            {
                _isMaleChecked = value;
                OnPropertyChanged("IsMaleChecked");
            }
        }

        private bool _isFemaleChecked;
        public bool IsFemaleChecked
        {
            get { return _isFemaleChecked; }
            set
            {
                _isFemaleChecked = value;
                OnPropertyChanged("IsFemaleChecked");
            }
        }

        private string _saveOrUpdateText;
        public string SaveOrUpdateText
        {
            get { return _saveOrUpdateText; }
            set
            {
                _saveOrUpdateText = value;
                OnPropertyChanged("SaveOrUpdateText");
            }
        }

        
        private void BrowseFile(object obj)
        {
            var fdlg = new System.Windows.Forms.OpenFileDialog();
            fdlg.Title = "C# Corner Open File Dialog";
            fdlg.InitialDirectory = @"c:\";
            fdlg.Filter = "All files (*.*)|*.*|All files (*.*)|*.*";
            fdlg.FilterIndex = 2;
            fdlg.RestoreDirectory = true;
            if (fdlg.ShowDialog()== DialogResult.OK)
            {
                Persons.FilePath = fdlg.FileName;
                OnPropertyChanged("Persons");
            }
        }

        private void SavePersonData(object obj)
        {
            Message = String.Empty;

            Person data = new Person();
            data.Id = Persons.Id;
            data.Name = Persons.Name;
            data.Gender = _isMaleChecked ? "Male":"Female";
            data.Mobile = Persons.Mobile;
            data.Address = Persons.Address;
            data.Email = Persons.Email;
            data.FilePath = Persons.FilePath;
            data.binary = !string.IsNullOrEmpty(data.FilePath) ? FileToByteArray(data.FilePath) : null;

            var personService = new PersonService();

            if (!IsUpdate)
            {
                bool IsSaved = personService.SavePerson(data);
                Message = IsSaved ? "Person Saved successfully." : "Person Saved failed.";
            }
            else
            {
                bool IsUpdated = personService.UpdatePerson(data);
                Message = IsUpdated ? "Person data updated successfully." : "Person data update failed.";
            }

            OnPropertyChanged("Message");

        }

        private void ClearPersonData(object obj)
        {
            Persons = new Person();
        }
        public byte[] FileToByteArray(string _FileName)
        {
            byte[] _Buffer = null;
            try
            {
                // Open file for reading 
                System.IO.FileStream _FileStream = new System.IO.FileStream(_FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                // attach filestream to binary reader 
                System.IO.BinaryReader _BinaryReader = new System.IO.BinaryReader(_FileStream);
                // get total byte length of the file 
                long _TotalBytes = new System.IO.FileInfo(_FileName).Length;
                // read entire file into buffer 
                _Buffer = _BinaryReader.ReadBytes((Int32)_TotalBytes);
                // close file reader 
                _FileStream.Close();
                _FileStream.Dispose();
                _BinaryReader.Close();
            }
            catch (Exception _Exception)
            {
                // Error 
                Console.WriteLine("Exception caught in process: {0}", _Exception.ToString());
            }
            return _Buffer;
        }
        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }
    }
}
