﻿using System.Windows;
using WPFDashBoardApp.MVVM.Models;
using WPFDashBoardApp.MVVM.ViewModels;

namespace WPFDashBoardApp.MVVM.Views
{
    /// <summary>
    /// Interaction logic for DashBoard.xaml
    /// </summary>
    public partial class DashBoard : Window
    {
        public DashBoard(User user)
        {
            InitializeComponent();
            var dashBoardVM = new DashBoardViewModel(user);
            this.DataContext = dashBoardVM;
        }
    }
}
