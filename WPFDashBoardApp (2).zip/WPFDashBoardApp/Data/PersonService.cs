﻿using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using WPFDashBoardApp.MVVM.Models;

namespace WPFDashBoardApp.Data
{
    internal class PersonService
    {

        private string conStr = string.Empty;

        public PersonService()
        {
            conStr = "Server=localhost;Database=SONY;Trusted_Connection=True;";
        }

        public bool SavePerson(Person p)
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            
            //string query= "Insert into [Person](name,mobile,gender,address,email)" +
            //       "Values('" + p.Name + "','" + p.Mobile + "','" + p.Gender + "','" + p.Address + "','" + p.Email + "')";

            string query = "insert into [Person] (name,mobile,gender,address,email,filedata) values(@name,@mobile,@gender,@address,@email,@filedata)";

            try
            {
                con = new SqlConnection(conStr);
                cmd = new SqlCommand(query, con);
                cmd.Parameters.Add(new SqlParameter("@name", (object)p.Name));
                cmd.Parameters.Add(new SqlParameter("@mobile", (object)p.Mobile));
                cmd.Parameters.Add(new SqlParameter("@gender", (object)p.Gender));
                cmd.Parameters.Add(new SqlParameter("@address", (object)p.Address));
                cmd.Parameters.Add(new SqlParameter("@email", (object)p.Email));
                cmd.Parameters.Add(new SqlParameter("@filedata", (object)p.binary));

                //Open connection and execute insert query.
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }

            return true;
        }

        public bool UpdatePerson(Person p)
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            bool IsSuccess = false;
            string query = string.Format("Update [Person] set name='{0}',mobile='{1}',gender='{2}',address='{3}',email='{4}' where Id={5}",p.Name,p.Mobile,p.Gender,p.Address,p.Email,p.Id);
            try
            {
                con = new SqlConnection(conStr);
                cmd = con.CreateCommand();
                con.Open();
                cmd.CommandText = query;

                cmd.Connection = con;
                int i=cmd.ExecuteNonQuery();
                IsSuccess = true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }

            return IsSuccess;
        }

        public bool DeletePerson(Person p)
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            bool IsSuccess = false;
            string query = string.Format("Delete from [Person] where Id={0}", p.Id);
            try
            {
                con = new SqlConnection(conStr);
                cmd = con.CreateCommand();
                con.Open();
                cmd.CommandText = query;

                cmd.Connection = con;
                int i = cmd.ExecuteNonQuery();
                IsSuccess = true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }

            return IsSuccess;
        }

        public ObservableCollection<Person> GetAllPerson()
        {
            var persons = new ObservableCollection<Person>();

            string sql = "select * from [Person]";
            string connetionString = "Server = localhost; Database = SONY; Trusted_Connection = True";

            SqlCommand cmd = null;
            var con = new SqlConnection(connetionString);
            try
            {
                con.Open();
                cmd = new SqlCommand(sql, con);
                var dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    var person = new Person();
                    person.Id = Convert.ToInt32(dataReader.GetValue(0));
                    person.Name = Convert.ToString(dataReader.GetValue(1));
                    person.Mobile = Convert.ToString(dataReader.GetValue(2));
                    person.Gender = Convert.ToString(dataReader.GetValue(3));
                    person.Address = Convert.ToString(dataReader.GetValue(4));
                    person.Email = Convert.ToString(dataReader.GetValue(5));
                    person.binary = (dataReader.GetValue(6) != DBNull.Value) ? (byte[])dataReader.GetValue(6) : null;

                    if (person.binary != null)
                    {
                        BitmapImage bitImage = new BitmapImage();
                        bitImage.BeginInit();
                        bitImage.CreateOptions = BitmapCreateOptions.None;
                        bitImage.CacheOption = BitmapCacheOption.Default;
                        bitImage.StreamSource = new MemoryStream(person.binary);
                        bitImage.EndInit();

                        person.Image =bitImage;
                    }

                    persons.Add(person);
                }
                dataReader.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return persons;
        }


    }
}
