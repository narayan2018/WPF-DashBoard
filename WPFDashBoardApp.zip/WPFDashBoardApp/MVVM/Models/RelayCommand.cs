﻿using System;
using System.Windows.Input;

namespace WPFDashBoardApp.MVVM.Models
{
    internal class RelayCommand : ICommand
    {
        private Action<object> _execute;
        private Func<object, bool> _executeFunc;

        public RelayCommand(Action<object> execute, Func<object, bool> executeFunc)
        {
            _execute = execute;
            _executeFunc = executeFunc;
        }
        public RelayCommand(Action<object> execute)
        {
            _execute = execute;
        }
        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return this._executeFunc == null || this._executeFunc(parameter);
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }
    }
}
