﻿using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace WPFDashBoardApp.MVVM.Models
{
    public class Person
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public string Mobile { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public string FilePath { get; set; }

        public byte[] binary { get; set; }

        public BitmapImage Image { get; set; }

    }
}
