﻿using System.Windows;
using WPFDashBoardApp.MVVM.Models;
using WPFDashBoardApp.MVVM.ViewModels;

namespace WPFDashBoardApp.MVVM.Views
{
    /// <summary>
    /// Interaction logic for PersonPage.xaml
    /// </summary>
    public partial class PersonPage : Window
    {
        public PersonPage(Person p)
        {
            InitializeComponent();
            var personVm = new PersonViewModel(p);
            this.DataContext= personVm;
        }
    }
}
