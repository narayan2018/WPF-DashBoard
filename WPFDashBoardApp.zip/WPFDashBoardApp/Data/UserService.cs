﻿using System;
using System.Data.SqlClient;
using WPFDashBoardApp.MVVM.Models;

namespace WPFDashBoardApp.Data
{
    internal class UserService
    {
        private string conStr=string.Empty;
        public UserService()
        {
            conStr = "Server=localhost;Database=SONY;Trusted_Connection=True;";
        }

        public bool ValidateLogin(User user)
        {
            User user2 = GetUser(user);
            bool IsSuccess = false;
            if(user.UserName==user2.UserName && user.UserPassword==user.UserPassword)
            {
                IsSuccess = true;
            }else
            {
                IsSuccess = false;
            }

            return IsSuccess;
        }
        private User GetUser(User u)
        {
            string sql = "select * from [User] where username='" + u.UserName + "'" + "and UserPassword='" + u.UserPassword + "'";
            string connetionString = "Server = localhost; Database = SONY; Trusted_Connection = True";

            SqlCommand cmd = null;
            var user = new User();
            var connection = new SqlConnection(connetionString);
            try
            {
                connection.Open();
                cmd = new SqlCommand(sql, connection);
                var dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    user.Id = Convert.ToInt32(dataReader.GetValue(0));
                    user.UserName = Convert.ToString(dataReader.GetValue(1));
                    user.UserPassword = Convert.ToString(dataReader.GetValue(2));
                }
                dataReader.Close();
            }
            catch (Exception ex)
            {
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }
            return user;
        }
    }
}
